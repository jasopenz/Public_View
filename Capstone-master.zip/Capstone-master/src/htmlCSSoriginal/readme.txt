These files are the original design in just HTML and CSS.
